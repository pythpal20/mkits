<?php 
function rupiah($angka){
	
	$hasil_rupiah = number_format($angka,0,',','.');
	return $hasil_rupiah;
 
}
// Database connection info 
$dbDetails = array( 
    'host' => 'localhost', 
    'user' => 'root', 
    'pass' => '', 
    'db'   => 'horek940_salsys'
); 
 
// DB table to use 
// $table = 'members'; 
$table = <<<EOT
 (
    SELECT 
      a.No_Co,
      a.tgl_order,
      a.tgl_krm,
      a.no_bl,
      a.status_delivery,
      c.customer_nama,
      SUM(b.harga_total) AS uang,
      a.status,
      a.sales,
      a.issuedby,
      a.keterangan
    FROM customerorder_hdr a
    JOIN customerorder_dtl b ON a.No_Co = b.No_Co
    JOIN master_customer c ON a.customer_id = c.customer_id
    -- WHERE a.status = '1' AND a.status_delivery ='0'
    GROUP BY b.No_Co
 ) temp
EOT;
 
// Table's primary key 
$primaryKey = 'No_Co';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
    array( 'db' => 'No_Co', 'dt' => 0 ),
    array( 'db' => 'no_bl', 'dt' => 1 ),
    array( 'db' => 'tgl_order', 'dt' => 2 ),
    array( 'db' => 'tgl_krm', 'dt' => 3 ),
    array( 'db' => 'customer_nama', 'dt' => 4 ),
    // array( 'db' => 'uang', 'dt' => 5, "formatter" => function ($d, $row){
    //     return rupiah($d);
    // }),
    array( 'db' => 'issuedby', 'dt' => 5),
    array( 'db' => 'sales', 'dt' =>6),
    array( 'db' => 'status_delivery', 'dt' =>7,  "formatter" => function ($d, $row){
        return $retVal = ($d == '0') ? "<label class='label label-default'>belum proses</label>" : "<label class='label label-primary'>sudah proses</label>" ;
    }),
);
// Include SQL query processing class 
require 'ssp.php'; 

// require('ssp.class.php');

// Output data as json format 
echo json_encode( 
	SSP::simple( $_GET, $dbDetails, $table, $primaryKey, $columns, null)
    // SSP::simple( $_GET, $dbDetails, $table, $primaryKey, $columns)

);